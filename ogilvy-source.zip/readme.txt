
./config/dbcon.php - contains db configuration
./model - contains all the db accessing modules of app
./view - this folder contains UIs for app
./control - contains the controllers of app
./lib - contains external libraries

please inmport the sql script to your DB
then change configuration in ./config/dbcon.php
open ./view folder, it contains the views

<?php


/**
* 	DB connection
*/

$host="127.0.0.1";
$user="ks";
$pass="1";
$db="k1";


?>